package exceptionHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileNotFoundDemo {
	public static void main(String[] args) throws IOException {
		System.out.println("Program starts");
		try {
			FileInputStream fis= new FileInputStream("C:\\Users\\gbatkirir\\eclipse-practice\\TrainingAssignmentJava\\src\\exceptionHandling");
		} catch (FileNotFoundException e) {
		System.out.println(e);
			}
		System.out.println("Program ends");
	}
}
