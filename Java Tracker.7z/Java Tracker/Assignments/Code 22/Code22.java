public class Frequency_of_charecter {

    public static void main(String[] args) {
        String str = "Batkiri Goutham Kumar is an Employee";
        char ch = 'e';
        int frequency = 0;

        for(int i = 0; i < str.length(); i++) {
            if(ch == str.charAt(i)) {
                ++frequency;
            }
        }

        System.out.println("Frequency of " + ch + " = " + frequency);
    }
}